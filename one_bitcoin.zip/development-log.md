1st Status update: 04/09/2019
The primary functionality of the app is in place and working. Most of the images and the logo are in their final form. I do not foresee any issues in completing on time. Documentation is still in a very early stage, so I will need to work on that. Flow chart and trello are done Stretch goals are to include an easy mode which allows the user to be plus or minus 10 to be correct. I have not implemented yet as I feel this game should be as frustrating as the bitcoin market.


2nd Status update: 05/09/2019
My app is now in it’s completed form, I may add a few more objects. I have redone all the images last night and do not anticipate any further style changes. I have run all tests and have not found any issues. All styling is complete and I don’t anticipate any further styling changes. I will be completing the documentation today and I do not anticipate any issues between now and submission. 
